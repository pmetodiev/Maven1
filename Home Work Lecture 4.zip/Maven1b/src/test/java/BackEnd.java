import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BackEnd {

    private static WebDriver driver;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\Webdrivers\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("http://shop.pragmatic.bg/admin/");
        driver.manage().window().maximize();

    }
    @Test
    public void userNameAndPasswordTest() {
        WebElement userName = driver.findElement(By.id("input-username"));
        userName.sendKeys("admin");

        WebElement password = driver.findElement(By.id("input-password"));
        password.sendKeys("parola123!");
        String password1= password.getText();
        String actualPassword=password1;
        String expectedPassword=password.getText();
        Assert.assertEquals(actualPassword,expectedPassword);

        if (password1.equalsIgnoreCase(expectedPassword)){
            System.out.println("Successfully log in");

        }
        else  {
            System.out.println("Wrong password");
        }

        WebElement logInButton = driver.findElement(By.xpath("//button[@type='submit']"));
        logInButton.click();

        WebElement logOutButton = driver.findElement(By.xpath("//a[contains(@href, 'logout')]"));
        String logOutButtonText = logOutButton.getText();
        Assert.assertEquals(logOutButtonText, "Logout");



//    }@Test
//    public void dropDownStatusTest(){

        WebElement dropDownStatus = driver.findElement(By.xpath("//select[@id='input-order-status']"));
        Select selectDropDownStatus=new Select(dropDownStatus);
        Assert.assertFalse(selectDropDownStatus.isMultiple());
        List<WebElement> allDropdown=selectDropDownStatus.getOptions();
        List<String>expectedOptions= Arrays.asList();
        List<String>actualOptions=new ArrayList<>();

        for (int i = 0; i <allDropdown.size() ; i++) {
            String currentElementTex=allDropdown.get(i).getText();
            actualOptions.add(currentElementTex);
            Assert.assertEquals(actualOptions,expectedOptions);
            selectDropDownStatus.selectByIndex(5);
            logOutButton.click();
        }
    }

    @AfterMethod
    public void afterTest(){

        driver.quit();
    }
}








